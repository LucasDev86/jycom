package com.lucasdev.bookreview.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SearchBooksDto {
    @SerializedName("title")
    String title;
    @SerializedName("item")
    List<Book> books;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }
}
