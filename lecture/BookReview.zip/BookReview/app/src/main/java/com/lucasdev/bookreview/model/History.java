package com.lucasdev.bookreview.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class History {
    @PrimaryKey
    public int uid;
    @ColumnInfo(name = "keyword")
    public String keyword;
}
