package com.lucasdev.bookreview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;

import com.lucasdev.bookreview.adapter.BookAdapter;
import com.lucasdev.bookreview.api.BookAPI;
import com.lucasdev.bookreview.model.BestSellerDto;
import com.lucasdev.bookreview.model.Book;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {


    final static String BASE_URL = "https://book.interpark.com/";

    private AppDatabase appDatabase;
    private BookAdapter adapter;
    private ArrayList<Book> bookArrayList = new ArrayList<Book>();
    private BookAPI bookAPI;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        appDatabase = Room.databaseBuilder(
                getApplicationContext(),
                AppDatabase.class,
                "historyDB"
        ).build();

        adapter = new BookAdapter(bookArrayList, this, new BookAdapter.BookListener() {

            @Override
            public void onBodyClick(Book book) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("bookModel", book);
                startActivity(intent);
            }
        });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setAdapter(adapter);

        Retrofit retrofit = new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();
        bookAPI = retrofit.create(BookAPI.class);
        bookAPI.getBestSeller(getString(R.string.interpark_apikey))
                .enqueue(new Callback<BestSellerDto>() {
                    @Override
                    public void onResponse(Call<BestSellerDto> call, Response<BestSellerDto> response) {
                        if (!response.isSuccessful()) {
                            return;
                        }

                        bookArrayList.addAll(response.body().getBooks());
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onFailure(Call<BestSellerDto> call, Throwable t) {

                    }
                });


    }
}