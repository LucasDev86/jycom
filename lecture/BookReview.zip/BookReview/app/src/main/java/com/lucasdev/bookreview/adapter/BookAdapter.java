package com.lucasdev.bookreview.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.lucasdev.bookreview.R;
import com.lucasdev.bookreview.model.Book;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.MyViewHolder> {

    private List<Book> bookList;
    private Context mContext;
    private BookListener listener;

    public BookAdapter(List<Book> bookList1, Context mContext, BookListener listener) {
        this.bookList = bookList1;
        this.mContext = mContext;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_book_2, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Book book = bookList.get(position);

        Glide.with(holder.iv_icon.getContext())
                .load(book.getCoverSmallUrl())
                .into(holder.iv_icon);

        holder.name.setText(book.getTitle());
        holder.discount.setText(book.getDescription());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onBodyClick(book);
            }
        });
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView iv_icon;
        public TextView name;
        public TextView discount;

        public MyViewHolder(View view) {
            super(view);
            iv_icon = view.findViewById(R.id.coverImageView);
            name = view.findViewById(R.id.titleTextView);
            discount = view.findViewById(R.id.descriptionTextView);
        }
    }

    public interface BookListener {
        void onBodyClick(Book book);
    }

}
