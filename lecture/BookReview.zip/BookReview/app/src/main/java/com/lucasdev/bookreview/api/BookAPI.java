package com.lucasdev.bookreview.api;

import com.lucasdev.bookreview.model.BestSellerDto;
import com.lucasdev.bookreview.model.SearchBooksDto;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface BookAPI {

    @GET("/api/bestSeller.api?categoryId=100&output=json")
    Call<BestSellerDto> getBestSeller(@Query("key") String apiKey);

    @GET("/api/search.api?output=json")
    Call<SearchBooksDto> getBooksByName(
            @Query("key") String apiKey,
            @Query("query") String keyword
    );
}
