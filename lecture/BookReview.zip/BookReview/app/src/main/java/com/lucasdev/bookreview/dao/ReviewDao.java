package com.lucasdev.bookreview.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.lucasdev.bookreview.model.History;
import com.lucasdev.bookreview.model.Review;

import java.util.List;

@Dao
public interface ReviewDao {
    @Query("SELECT * FROM history")
    List<History> getAll();

    @Insert
    void insertHistory(History history);

    @Query("SELECT * FROM review WHERE uid = :uid")
    Review getOne(int uid);

}
