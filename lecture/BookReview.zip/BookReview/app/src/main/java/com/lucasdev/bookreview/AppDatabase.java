package com.lucasdev.bookreview;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.lucasdev.bookreview.dao.HistoryDao;
import com.lucasdev.bookreview.dao.ReviewDao;
import com.lucasdev.bookreview.model.History;
import com.lucasdev.bookreview.model.Review;

@Database(entities = {History.class , Review.class}, version = 2)
abstract class AppDatabase extends RoomDatabase {
    abstract HistoryDao historyDao();

    abstract ReviewDao reviewDao();

}
