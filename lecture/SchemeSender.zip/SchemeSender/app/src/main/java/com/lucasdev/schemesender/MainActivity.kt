package com.lucasdev.schemesender

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.lucasdev.schemesender.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btn0.setOnClickListener {
            binding.edit.setText("bizzeropay://hub_onlnpg?")
        }
        binding.btn1.setOnClickListener {
            binding.edit.setText("bizzeropay://zeropay?callbackfunc=")
        }
        binding.btn2.setOnClickListener {
            binding.edit.setText("bizzeropay://seoul/list")
        }
        binding.btn3.setOnClickListener {
            binding.edit.setText("bizzeropay://seoul/qrCode")
        }
        binding.btn4.setOnClickListener {
            binding.edit.setText("kakao4407cff2682e1eccc5026c88d81e62bb://kakaolink?menu_id=UNTACT_PAY_LIST&menu_data={'type':'WEB','url':'main_onaf_list.act','param':{}}")
        }
        binding.btn5.setOnClickListener {
            binding.edit.setText("kakaob59e3d0ee86f431a8a96fa44decc7a52://kakaolink?menu_id=UNTACT_PAY_LIST&menu_data={'type':'WEB','url':'main_onaf_list.act','param':{}}")
        }

        binding.btnGo.setOnClickListener {

            var str = "${binding.edit?.text}".trim()

            if (str.isEmpty()){
                Toast.makeText(applicationContext, "실행할 스키마가 없습니다.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("$str"))
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(applicationContext, "정상적인 스키마가 아닙니다.", Toast.LENGTH_SHORT).show()
            }


        }


    }
}